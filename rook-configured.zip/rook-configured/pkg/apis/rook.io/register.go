package rookio

const (
	CustomResourceGroupName = "rook.io"
)
