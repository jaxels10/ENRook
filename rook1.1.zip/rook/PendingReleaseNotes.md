# Major Themes

v1.6...

## K8s Version Support

## Upgrade Guides

## Breaking Changes

### Ceph

## Features

### Core

### Ceph

* CephClient CRD has been converted to use the controller-runtime library
* Extending the support of vault KMS configuration for Ceph RGW
