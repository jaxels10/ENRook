package edgefsrookio

const (
	CustomResourceGroupName = "edgefs.rook.io"
)
