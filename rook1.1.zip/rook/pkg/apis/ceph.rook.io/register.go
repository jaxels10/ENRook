package cephrookio

const (
	CustomResourceGroupName = "ceph.rook.io"
)
